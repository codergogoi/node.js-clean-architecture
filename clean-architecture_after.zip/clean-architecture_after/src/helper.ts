export const SendSendGridEmail = async (product: any) => {
  // send email
};

export const NotifyToPromotionService = async (product: any) => {
  // do something
};
